<?php
#error login
$lang['login_err_required'] = "Username atau password harus diisi!";
$lang['login_err_required_password'] = "Password minimal 6 karakter !<br>";
$lang['login_err_user'] = "Username atau password salah!";
?>